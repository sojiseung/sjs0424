# from flask_wtf import FlaskForm
# from wtforms import StringField, PasswordField, TextAreaField, DateField
# from wtforms.validators import DataRequired


# class TaskForm(FlaskForm):
#     title = StringField("Title", validators=[DataRequired()])
#     contents = TextAreaField("Contents", validators=[DataRequired()])
#     due_date = DateField("Due Date", validators=[DataRequired()])


